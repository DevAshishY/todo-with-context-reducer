import { useState } from 'react';
import './App.css';
import DeletedItem from './componets/DeletedItem/DeletedItem';
import Header from './componets/Header/Header';
import List from './componets/List/List';
import TodoInput from './componets/TodoInput/TodoInput';



const App = () => {
  
const [item,setItem] = useState([]);
const[deleteItem,setDeleteItem] = useState([])
const [editedData,setEditedData] = useState()
const [editedDataIndex,setEditedDataIndex] = useState()


 
  
  const inputHandler = (itemName) =>{
    console.log(editedDataIndex);
    if(editedDataIndex != undefined){
           const updateData = item.map((dataItem ,index)=>{
            if(index == editedDataIndex){
              return {...dataItem,name:itemName}
            }
            return dataItem
           })
           setItem(updateData)
           setEditedDataIndex(undefined)
    }
    else{
      setItem([...item,{name:itemName}])

    }
 
  }

  const deleteId = (e) =>{
    let deletedData = item.filter((item,index)=>{
      return e == index
     })
     setDeleteItem([...deleteItem,...deletedData])
    let updatedData = item.filter((item,index)=>{
     return e != index
    })
    setItem(updatedData)
    

   
  }


  // Edit

  const  editDataOnparent =(editItemData,editIndex)=>{
    setEditedData(editItemData)
    setEditedDataIndex(editIndex)
    
       }

  return (
    <>
    {

    }
      <Header />
      <div className="toApp">
        <div className="container-fluid">
          {/* input for todo */}
          <div className="row">
            <div className="col">
              <TodoInput inputHandler={inputHandler}  editedData={editedData}/>
            </div>
          </div>

           {/* List for added item */}
          <h6 className='mt-4'>Todo list</h6>
          <div className="row mt-4">
            <div className="col">
              <ul className="list-group">
                <List  initialdata={item} deleteId={deleteId}   editDataOnparent={editDataOnparent}/>
              </ul>
            </div>
          </div>
           {/* List for deleted item */}
          <h6 className='mt-4'>Deleted Item</h6>
          <div className="row mt-4">
            <div className="col">
              <ul className="list-group">
                <DeletedItem  deleteItem={deleteItem}/>
              </ul>
            </div>
          </div>
        </div>
      </div>

    </>
  )
}
export default App;