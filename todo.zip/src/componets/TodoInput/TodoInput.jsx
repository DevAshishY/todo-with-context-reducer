import { useEffect,useState } from "react";

const TodoInput = ({inputHandler,editedData}) =>{
    const [input,setInput]= useState(null)

    // asadsadasd
console.log(editedData);

useEffect(()=>{
    setInput(editedData)
},[editedData])



      
    const getData = (e) =>{
            setInput(e.target.value)

        }

    function sendData(){
        
        if(input){
            inputHandler(input)
            setInput('')
            
        }
        
    }
    return(
<>
<div className="input-group mb-3">
                <input type="text" className="form-control" value={input} placeholder="Please enter a item" onChange={(e)=>getData(e)} />

                <button className="btn btn-secondary" type="button" id="button-addon2" onClick={()=>sendData()}>Add item</button>
              </div>
</>
    )
}

export default TodoInput;